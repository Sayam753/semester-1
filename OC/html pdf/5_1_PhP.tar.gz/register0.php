<!DOCTYPE html><!--register0.php-->
<html>
  <head>
    <title>Registered!</title>
  </head>
  <body>
    <h1>Hello, <?php echo $_GET['name'] ?>!</h1>
    <h1>You are a <?php echo $_GET['gender'] ?></h1>
    <h1>You are from <?php echo $_GET['state'] ?></h1>
  </body>
</html>




