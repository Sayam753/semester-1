int main(int argc, char* argv[])
{
    int argcctr=0;

    printf("The no of arguments are: %d\n", argc);
    for(argcctr=0;argcctr<argc;argcctr++)
    {
        printf("Argument %d is : %s\n", argcctr,argv[argcctr]);

    }

    return 0;
}
