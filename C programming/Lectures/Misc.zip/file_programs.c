C Program to merge contents of two files into a third file
Let the given two files be file1.txt and file2.txt. The following are steps to merge. 
1) Open file1.txt and file2.txt in read mode.
2) Open file3.txt in write mode.
3) Run a loop to one by one copy characters of file1.txt to file3.txt.
4) Run a loop to one by one copy characters of file2.txt to file3.txt.
5) Close all files.

To successfully run the below program file1.txt and fil2.txt must exits in same folder.

#include <stdio.h> 
#include <stdlib.h> 
  
int main() 
{ 
   // Open two files to be merged 
   FILE *fp1 = fopen("file1.txt", "r"); 
   FILE *fp2 = fopen("file2.txt", "r"); 
  
   // Open file to store the result 
   FILE *fp3 = fopen("file3.txt", "w"); 
   char c; 
  
   if (fp1 == NULL || fp2 == NULL || fp3 == NULL) 
   { 
         puts("Could not open files"); 
         exit(0); 
   } 
  
   // Copy contents of first file to file3.txt 
   while ((c = fgetc(fp1)) != EOF) 
      fputc(c, fp3); 
  
   // Copy contents of second file to file3.txt 
   while ((c = fgetc(fp2)) != EOF) 
      fputc(c, fp3); 
  
   printf("Merged file1.txt and file2.txt into file3.txt"); 
  
   fclose(fp1); 
   fclose(fp2); 
   fclose(fp3); 
   return 0; 
} 


#include <stdio.h>
#include <stdlib.h>

struct threeNum
{
   int n1, n2, n3;
};

int main()
{
   int n;
   struct threeNum num;
   FILE *fptr;

   if ((fptr = fopen("C:\\program.bin","wb")) == NULL){
       printf("Error! opening file");

       // Program exits if the file pointer returns NULL.
       exit(1);
   }

   for(n = 1; n < 5; ++n)
   {
      num.n1 = n;
      num.n2 = 5*n;
      num.n3 = 5*n + 1;
      fwrite(&num, sizeof(struct threeNum), 1, fptr); 
   }
   fclose(fptr); 
  
   return 0;
}
In this program, you create a new file program.bin in the C drive.




#include <stdio.h>
#include <stdlib.h>

struct threeNum
{
   int n1, n2, n3;
};

int main()
{
   int n;
   struct threeNum num;
   FILE *fptr;

   if ((fptr = fopen("C:\\program.bin","rb")) == NULL){
       printf("Error! opening file");

       // Program exits if the file pointer returns NULL.
       exit(1);
   }

   for(n = 1; n < 5; ++n)
   {
      fread(&num, sizeof(struct threeNum), 1, fptr); 
      printf("n1: %d\tn2: %d\tn3: %d", num.n1, num.n2, num.n3);
   }
   fclose(fptr); 
  
   return 0;
}


/* Read the words in a file*/
#include <stdio.h>
#include <stdlib.h>
 
int main(int argc, char * argv[])
{
	// This program reads a file from its arguments and prints a word by word. Additionally, it counts the words in the file.
	if (argc < 2) return 1;
	char * filename = argv[1];
	FILE * fp = fopen(filename, "r");
	if (fp == NULL) return 1;
	char c;
	int count = 0;
	while((c = fgetc(fp)) != EOF)
	{
		if(c == ' ' || c == '\n')
		{
			printf("\n");
			++count;
		}
		else
		{
			printf("%c", c);
		}
	}
	fclose(fp);
 
	printf("This file has %d words in it.", count);
	return 0;
}

/*Store words from text file to an array in C Program*/
#include <stdio.h>
#include <stdlib.h>
 
int main(int argc, char const *argv[])
{
    FILE* inp;
    inp = fopen("filename","r");		//filename of your data file
    char arr[100][50];			//max word length 50
    int i = 0;
    while(1){
        char r = (char)fgetc(inp);
        int k = 0;
        while(r!=',' && !feof(inp)){	//read till , or EOF
            arr[i][k++] = r;			//store in array
            r = (char)fgetc(inp);
        }
        arr[i][k]=0;		//make last character of string null 
        if(feof(inp)){		//check again for EOF
            break;
        }
        i++;
    }
    int j;
    //for(j = 0;j<=i;j++){
    //    printf("%s\n",arr[j] );	//print array
    //}
    return 0;
}


volatile