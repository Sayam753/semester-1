// C program to demonstrate working of
// variable arguments to find average
// of multiple numbers.
#include <stdarg.h>
#include <stdio.h>

int average(int num, ...)
{
    va_list valist;

    int tmp,sum = 0, i;
    printf("\nThe number: %d\n",num);

    va_start(valist, num);
    for (i = 0; i < num; i++)
    {
        tmp = va_arg(valist, int);
        printf("no %d argument %d",i, tmp);
        sum+= tmp;
    }

    va_end(valist);

    return sum / num;
}

// Driver code
int main()
{
    int count=0;
    count=3;
    printf("Average of {2, 3, 4} = %d\n",
                         average(count,2, 3, 4));
    count = 4;
    printf("Average of {3, 5, 10, 15} = %d\n",
                      average(count, 3, 5, 10, 15));
    return 0;
}
