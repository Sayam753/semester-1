#include<stdio.h>
struct student
{
  int Roll;
  float cgpa;
  int year;
};

void main()
{
  int i;
  struct student s,*ptr;
  printf("Enter Roll, cgpa, and year:\n");
  scanf("%d,%f,%d",&s.Roll,&s.cgpa,&s.year);
  ptr = &s;
  printf("size of students = %d bytes\n",sizeof(s));
  printf("ptr = %u, ptr+1 = %u\n",ptr,ptr+1);
 
}
