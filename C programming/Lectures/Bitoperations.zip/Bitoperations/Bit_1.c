#include<stdio.h>
void showbits(unsigned char n);

void main()
{
  int i;
  char ch = 60;
  signed char n = -24;
  unsigned char c = 65;
  
  printf("ch = ");

  showbits(ch);
  

  printf("n = ");/* 00011000, 11100111 + 1 = 11101000*/

  showbits(n);

  printf("c = ");

  showbits(c);

  printf("\n");

  printf("ch = %d\n",ch);
  printf("ch in hex = %x\n",ch);
  printf("ch in Hex = %X\n",ch);
}

void showbits(unsigned char n)
{
  int i;
  unsigned char j,k, andmask;

  for(i=7;i>=0;i--)
    {
      j = i;
      andmask = 1<<j;
      k = n & andmask;
      k==0?printf("0"):printf("1");
    }
  printf("\n");
}
