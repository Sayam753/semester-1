#include<stdio.h>
void showbits(unsigned char n);

void main()
{
  unsigned char ch = 0x20; /* bit pattern 0010 0000*/
  unsigned char c;

  printf("ch = ");
  showbits(ch);
  
  c = ~ch;
  printf("c = ");
  showbits(c);  
}

void showbits(unsigned char n)
{
  int i;
  unsigned char j,k, andmask;

  for(i=7;i>=0;i--)
    {
      j = i;
      andmask = 1<<j;
      k = n & andmask;
      k==0?printf("0"):printf("1");
    }
  printf("\n");
}
