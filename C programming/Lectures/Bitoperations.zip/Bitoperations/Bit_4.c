#include<stdio.h>
void showbits(unsigned char n);

void main()
{
  unsigned char ch = 0xAC;
  unsigned char c = 0x20,A;

  printf("ch = ");
  showbits(ch);
  
  printf("c = ");
  showbits(c);
  
  A = ch & c;
  printf("c AND ch = ");
  showbits(A);
  
  A = ch | c;
  printf("c OR ch = ");
  showbits(A);
  
  A = ch ^ c;
  printf("c XOR ch = ");
  showbits(A);
}

void showbits(unsigned char n)
{
  int i;
  unsigned char j,k, andmask;

  for(i=7;i>=0;i--)
    {
      j = i;
      andmask = 1<<j;
      k = n & andmask;
      k==0?printf("0"):printf("1");
    }
  printf("\n");
}
