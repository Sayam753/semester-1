#include<stdio.h>
void showbits(unsigned char n);

void main()
{
  unsigned char ch = 32,c;
  signed char n = -24;
  
  printf("ch = ");
  showbits(ch);

  c = ch >> 1;
  printf("ch >> 1 = ");
  showbits(c);

  c = ch >> 5;
  printf("ch >> 5 = ");
  showbits(c);


  c = n << 1;
  printf("ch << 1= ");
  showbits(c);

  c = n << 5;
  printf("ch << 5 = ");
  showbits(c);

}

void showbits(unsigned char n)
{
  int i;
  unsigned char j,k, andmask;

  for(i=7;i>=0;i--)
    {
      j = i;
      andmask = 1<<j;
      k = n & andmask;
      k==0?printf("0"):printf("1");
    }
  printf("\n");
}
