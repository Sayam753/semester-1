#include<stdio.h>

void main()
{
  for(int i=0;i<=10000;i++)
    printf("i=%d\n",i);
}
