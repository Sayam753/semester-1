#include<stdio.h>

int main()
{
  int m[5][3] = {{23,19,25},{12,17,20},{10,13,14},{21,14,18},{24,22,25}};
  int i,j;
  int (* p)[3];

  p = &m[0];
  printf("address of marks[0], p = %u, p+1 = %u\n\n",p,p+1);
  for(i=0;i<=4;i++)
    {
      for(j=0;j<=2;j++)
	printf("m[%d][%d] = %d\t",i,j,m[i][j]);
      printf("\n");
    }
  printf("\n\n");

  for(i=0;i<5;i++)
    printf("*(m+i) = %d\n",*(m+i));
  
  for(i=0;i<=4;i++)
    {
      for(j=0;j<=2;j++)
	printf("*(m[%d]+%d) = %d\t",i,j,*(m[i]+j));
      printf("\n");
    }
  printf("\n\n");
  for(i=0;i<=4;i++)
    {
      for(j=0;j<=2;j++)
	printf("*(*(m+%d)x+%d) = %d\t",i,j,*(*(m+i)+j));
      printf("\n");
    }
  return 0;
}
