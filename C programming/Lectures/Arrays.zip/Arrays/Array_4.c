#include<stdio.h>
float average(int *A,int n);
float Avg(int A[], int n)
{
  int i,sum = 0;
  float avg = 0.0;
  for(i=0;i<n;i++)
    {
      sum = sum + A[i];
    }
  avg = sum/10.0;
  return avg;
}
int main()
{
  int marks[10] = {23, 24, 12, 16, 9, 6, 25, 20, 12, 9};
  int i;
  float avg,avg_2;
  printf("----------------------------------------------------------------------\n");
  for(i=0;i<10;i++)
    printf("marks[%d] = %d,\t  *(marks + %d) = %d\n", i,marks[i],i,*(marks+i));
  printf("----------------------------------------------------------------------\n");
  for(i=0;i<10;i++)
    printf("*(i+marks) = %d,\t  i[marks] = %d\n",*(i+marks),i[marks]);
  printf("----------------------------------------------------------------------\n");
  avg = average(marks,10);
  avg_2 = Avg(marks,10);
  printf("\n\nAverage marks = %1.4f\n\n",avg);
  printf("\n\nAverage marks by value = %1.4f\n\n",avg_2);
  return 0;
}

float average(int *A,int n)
{
  int i,sum = 0;
  float avg = 0.0;
  for(i=0;i<n;i++)
    {
      sum = sum + A[i];
    }
  avg = sum/10.0;
  return avg;
}
