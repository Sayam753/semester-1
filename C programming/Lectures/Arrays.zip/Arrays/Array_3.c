#include<stdio.h>

int main()
{
  int marks[10] = {23, 24, 12, 16, 9, 6, 25, 20, 12, 9};
  int i,sum=0,*k;
  float avg;
  k = &sum;
  printf("---------------------------------------------------------\n");
  printf("Address of sum is %u\n",k);
  printf("k+3 = %u\n",k+3);
  int *point_array;
  point_array = &marks[0];
  printf("---------------------------------------------------------\n");
  printf("point_array = %u\n",point_array);
  printf("address of marks = %u\n", marks);
  printf("---------------------------------------------------------\n");
  printf("addition of two pointers: %u\n",point_array + k);
  for(i=0;i<10;i++)
    {
      sum = sum + marks[i];
    }
  avg = sum/10.0;
  printf("Average marks = %1.4f\n",avg);
  return 0;
}
