#include<stdio.h>

int main()
{
  int a[2+3];
  int k = 100,Arr[k];
  int c[] = {1,2,3};
  //scanf("%d",&k);
  int marks[10];
  int i,sum=0;
  float avg;
  for(i=0;i<10;i++)
    {
      printf("Enter marks[%d]:\n", i);
      scanf("%d",&marks[i]);
    }
  for(i=0;i<10;i++)
    {
      sum = sum + marks[i];
    }
  avg = sum/10.0;
  printf("Average marks = %1.4f\n",avg);
  return 0;
}
