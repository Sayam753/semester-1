#include<stdio.h>

int main()
{
  int marks[5][3] = {{23,19,25},{12,17,20},{0,3,14},{21,14,18},{24,22,25}};
  int a[5][3] = {{23,19,25},
		 {12,17,20},
		 {0,3,14},
		 {21,14,18},
		 {24,22,25}};
  int m[][3] = {23,19,25,12,17,20,0,3,14,21,14,18,24,22,25};
  int i,j;

  for(i=0;i<=4;i++)
    {
      for(j=0;j<=2;j++)
	printf("marks[%d][%d] = %d\t",i,j,marks[i][j]);
      printf("\n");
    }
  printf("\n\n");
  for(i=0;i<=4;i++)
    {
      for(j=0;j<=2;j++)
	printf("a[%d][%d] = %d\t",i,j,a[i][j]);
      printf("\n");
    }
  printf("\n\n");
  for(i=0;i<=4;i++)
    {
      for(j=0;j<=2;j++)
	printf("m[%d][%d] = %d\t",i,j,m[i][j]);
      printf("\n");
    }
  return 0;
}
