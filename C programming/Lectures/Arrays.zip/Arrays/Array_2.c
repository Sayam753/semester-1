#include<stdio.h>

int main()
{
  int marks[10] = {23, 24, 12, 16, 9, 6, 25, 20, 12, 9};
  int i,sum=0;
  float avg;
  for(i=0;i<10;i++)
    {
      sum = sum + marks[i];
    }
  avg = sum/10.0;
  printf("Average marks = %1.4f\n",avg);
  printf("Accessing outside array: marks[23] = %d\n", marks[23]);
  return 0;
}
