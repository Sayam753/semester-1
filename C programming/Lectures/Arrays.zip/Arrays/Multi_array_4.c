#include<stdio.h>

int main()
{
  int a[] = {1,2,3,4};
  int x = 10, y = 20, z = 30, w = 40;
  int *p[4],*q[4],*ptr;
  int i;
  q[0] = &w;
  q[1] = &x;
  q[2] = &y;
  q[3] = &z;
  ptr = &p[0];
  printf("q[0] = %u, q[1] = %u, q[2] = %u, q[3] = %u\n",q[0],q[1],q[2],q[3]);
  printf("Values at q[0] = %d, q[1] = %d, q[2] = %d, q[3] = %d\n",*q[0],*q[1],*q[2],*q[3]);
  
  for(i=0;i<=3;i++)
    p[i] = &a[i];
  
  printf("ptr = %u, p = %u, *p = %u, *(*p) = %d\n",ptr,p,*p,*(*p));
}
