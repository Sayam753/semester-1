#include<stdio.h>
float avg(int a[][3],int r, int c);
float Average(int (*a)[],int r, int c);
float avg_marks(int *a,int r,int c);

int main()
{
  int m[5][3] = {{23,19,25},{12,17,20},{10,13,14},{21,14,18},{24,22,25}};
  int i,j;
  float average;

  average = avg(m,5,3);
  printf("average marks = %1.2f\n",average);
  printf("average marks = %1.2f\n",Average(m,5,3));
  printf("average marks = %1.2f\n",avg_marks(m,5,3));
  
  return 0;
}

float avg(int a[][3], int r,int c)
{
  int i,j;
  float x = 0.0;
  for(i=0;i<r;i++)
    for(j=0;j<c;j++)
      x = x + (float)a[i][j];
  return x/(r*c);
}

float Average(int (*a)[3], int r,int c)
{
  int i,j;
  float x = 0.0;
  for(i=0;i<r;i++)
    for(j=0;j<c;j++)
      x = x + (float)*(*(a+i)+j);
  return x/(r*c);
}

float avg_marks(int *a, int r,int c)
{
  int i,j;
  float x = 0.0;
  for(i=0;i<r;i++)
    for(j=0;j<c;j++)
      x = x + (float)*(a+i*c+j);
  return x/(r*c);
}
