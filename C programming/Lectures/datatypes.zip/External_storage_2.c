#include<stdio.h>
#include "MyFunc.h"

int i,k;
int addition();

void main()
{
  //  extern int i,k; 
  //i = 10;
  //k = 15;
  printf("\nadding two integers, i+k = %d\n\n",addition());
  printf("\ndifference beween the two integers i and k = %d\n\n",difference());
}

int addition()
{
  return(i+k);
}
