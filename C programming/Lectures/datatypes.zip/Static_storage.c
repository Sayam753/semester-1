#include<stdio.h>

int increment();
int static_increment();

void main()
{
  int j,k;
  
  j = increment();
  printf("first call: j = %d\n",j);
  j = increment();
  printf("second call: j = %d\n",j);
  j = increment();
  printf("Third call: j = %d\n\n",j);

  k = static_increment();
  printf("first call: k = %d\n",k);
  k = static_increment();
  printf("second call: k = %d\n",k);
  k = static_increment();
  printf("Third call: k = %d\n",k);
}

int increment()
{
  int i=1;
  return(i++);
}

int static_increment()
{
  static int i=1;
  return(i++);
}
