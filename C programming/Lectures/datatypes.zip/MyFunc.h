extern int i,k;

int difference()
{
  if(i>k)
    return(i-k);
  else
    return(k-i);
}
