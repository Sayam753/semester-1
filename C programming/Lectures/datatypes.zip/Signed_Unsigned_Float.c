#include<stdio.h>

void main()
{
  int x=25534;
  float a = 25534;
  double b;
  long double c;
  printf("size of float is %d bytes\n",sizeof(a));
  printf("size of double is %d bytes\n",sizeof(b));
  printf("size of long double is %d bytes\n",sizeof(c));
  printf("%2.2f\n",a);
}
