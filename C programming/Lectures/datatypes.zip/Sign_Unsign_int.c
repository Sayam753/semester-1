#include<stdio.h>

void main()
{
  int x = 5743;
  long int i;
  unsigned int j;

  printf("size of signed int is %d bytes\n",sizeof(i));
  printf("size of unsigned int is %d bytes\n",sizeof(j));
  
  i = 675667875466787899876;
  j = -6;
  
  printf("i = %d,\nj = %u\n",i,j);
  printf("%1.4f\n",x);
}
