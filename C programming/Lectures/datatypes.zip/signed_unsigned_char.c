#include<stdio.h>

void main()
{
  signed char ch;
  unsigned char c;
  ch = 32;
  c = 291;
  printf("ch: %d\t %c,\n",ch,ch);
  printf("c: %d\t%c\n",c,c);
}
