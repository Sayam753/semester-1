#include<stdio.h>

void main()
{
  int i;
  char ch = 's';
  long k;
  short j;
  //printf("Enter i,j\n");
  //scanf("%d %d",&i,&j);
  printf("Size of int is %d\n",sizeof(i));
  printf("Size of long int is %d\n",sizeof(k));
  printf("Size of short int is %d\n",sizeof(j));
  printf("Size of char is %d\n",sizeof(ch));
  printf("ch = %c,%d\n",ch,ch);
}
