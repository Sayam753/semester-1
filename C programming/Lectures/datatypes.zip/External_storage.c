#include<stdio.h>

int i,k;
int addition();

void main()
{
   
  i = 10;
  k = 15;
  printf("i = %d\n",i);
  printf("\nadding two integers, i+k = %d\n\n",addition());
 
}

int addition()
{
  int i = 12;
  printf("i = %d\n",i);
  return(i+k);
}
