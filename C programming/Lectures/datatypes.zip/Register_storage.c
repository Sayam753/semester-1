#include<stdio.h>

void main()
{
  register int i;
  printf("Initial value of i = %d\n",i);
  for(i=0;i<10;i++)
    printf("i = %d\n",i);
}
