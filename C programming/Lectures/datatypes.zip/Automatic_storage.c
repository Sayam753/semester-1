#include<stdio.h>

void main()
{
  auto int x = 2;
  {
    auto int x = 4;
    {
      auto int x = 6;
      printf("x in block 3: %d\n",x);
    }
    printf("x in block 2: %d\n",x);
  }
  printf("x in block 1: %d\n",x);
}
